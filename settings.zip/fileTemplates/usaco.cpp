#[[#include]]# <bits/stdc++.h>

using namespace std;

int solve() {
	return 0;
}

int main() {
    ios::sync_with_stdio(false);
	cin.tie(nullptr);
	solve();
}
