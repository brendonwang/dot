#[[#include]]# <bits/stdc++.h>

#[[#include]]# <ext/pb_ds/assoc_container.hpp>
#[[#include]]# <ext/pb_ds/tree_policy.hpp>

/* NAMESPACE */

using namespace std;
using namespace __gnu_pbds;

/* HASH */

struct custom_hash {
	static uint64_t splitmix64(uint64_t x) {
		// http://xorshift.di.unimi.it/splitmix64.c
		x += 0x9e3779b97f4a7c15;
		x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9;
		x = (x ^ (x >> 27)) * 0x94d049bb133111eb;
		return x ^ (x >> 31);
	}

	size_t operator()(uint64_t x) const {
		static const uint64_t FIXED_RANDOM = chrono::steady_clock::now().time_since_epoch().count();
		return splitmix64(x + FIXED_RANDOM);
	}
};

template<class K, class V> using safe_map = unordered_map<K, V, custom_hash>;
template<class K, class V> using safe_ht = gp_hash_table<K, V, custom_hash>;
template<class K> using safe_set = unordered_set<K, custom_hash>;

/* TEMPLATES */

using ll = long long;
using pii = pair<int, int>;
template<class t> using pp = pair<t, t>;
using pll = pp<ll>;
using ordered_set = tree<ll, null_type, less<ll>, rb_tree_tag, tree_order_statistics_node_update>;
using vi = vector<int>;
using vii = vector<vi>;
using viii = vector<vii>;
using vll = vector<ll>;


/* MACROS */
#[[#define]]# clear(arr) memset(arr, 0, sizeof arr)
#[[#define]]# reset(arr) memset(arr, -1, sizeof arr)
#[[#define]]# YESNO(condition) condition ? "YES" : "NO"
#[[#define]]# set(a, b, c) a = c((a), (b))
#[[#define]]# set_min(a, b) set((a), (b), min)
#[[#define]]# set_max(a, b) set((a), (b), max)
#[[#define]]# sz(a) (int)(a).size()
#[[#define]]# all(a) (a).begin(), (a).end()

/* CONSTANTS */
const int inf = 2e9;
const ll infl = 4e18;
const ll MOD = 1e9 + 7;
const ll MAXN = 2e5;

int solve() {
	return 0;
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	solve();
}